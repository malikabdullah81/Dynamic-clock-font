# Dynamic Clock

One UI 8.5 style adaptive lock-screen clock live wallpaper.

Features:
- Digits + colon stretch to fit around subject
- Wake animation (stretch from top/bottom with bounce)
- Solid / Outline / Glass (borderless refractive) styles
- Full date customization
- Subject cut-out via ML Kit

Build with the included GitHub Actions workflow.
