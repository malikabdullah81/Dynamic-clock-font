package com.malik.dynamicclock

import android.graphics.Path
import android.graphics.RectF

/**
 * One UI 8.5 style tall rounded tube digits.
 * Designed to match the thick, rounded, slightly condensed look of the adaptive clock.
 */
object DigitShapes {

    // Normalized path data for digits 0-9 (width 1.0, height 1.6 for tall look)
    // Paths are designed so vertical stretch looks natural.

    fun getPath(digit: Char, width: Float, height: Float, stroke: Float): Path {
        val p = Path()
        val w = width
        val h = height
        val r = stroke * 0.55f   // corner radius relative to stroke
        val inset = stroke * 0.5f

        when (digit) {
            '0' -> {
                // Outer rounded rect
                p.addRoundRect(RectF(inset, inset, w - inset, h - inset), r * 1.8f, r * 1.8f, Path.Direction.CW)
                // Inner hole
                val inner = Path()
                val iR = r * 1.1f
                inner.addRoundRect(RectF(inset + stroke, inset + stroke, w - inset - stroke, h - inset - stroke), iR, iR, Path.Direction.CW)
                p.op(inner, Path.Op.DIFFERENCE)
            }
            '1' -> {
                // Vertical bar with slight top serif
                val barW = stroke * 1.15f
                val cx = w * 0.55f
                p.addRoundRect(RectF(cx - barW / 2, inset, cx + barW / 2, h - inset), r, r, Path.Direction.CW)
                // small top ledge
                p.addRoundRect(RectF(cx - barW * 1.3f, inset, cx + barW / 2, inset + stroke * 0.9f), r * 0.7f, r * 0.7f, Path.Direction.CW)
            }
            '2' -> {
                // Top curve + diagonal + bottom bar (simplified tube style)
                val midY = h * 0.48f
                p.moveTo(inset, inset + stroke)
                p.quadTo(inset, inset, inset + stroke, inset)
                p.lineTo(w - inset - stroke, inset)
                p.quadTo(w - inset, inset, w - inset, inset + stroke)
                p.lineTo(w - inset, midY - stroke * 0.3f)
                p.quadTo(w - inset, midY + stroke * 0.6f, w - inset - stroke * 1.2f, midY + stroke)
                p.lineTo(inset + stroke * 0.6f, h - inset - stroke * 0.4f)
                p.lineTo(inset + stroke * 0.6f, h - inset)
                p.lineTo(w - inset, h - inset)
                p.lineTo(w - inset, h - inset - stroke)
                p.lineTo(inset + stroke * 1.8f, h - inset - stroke)
                p.lineTo(w - inset - stroke * 0.5f, midY + stroke * 0.3f)
                p.quadTo(w - inset - stroke * 0.2f, midY - stroke * 0.2f, w - inset - stroke * 0.2f, midY - stroke)
                p.lineTo(w - inset - stroke * 0.2f, inset + stroke)
                p.lineTo(inset + stroke, inset + stroke)
                p.quadTo(inset + stroke * 0.3f, inset + stroke, inset + stroke * 0.3f, inset + stroke * 1.5f)
                p.close()
            }
            '3' -> {
                // Two stacked rounded C shapes
                val mid = h * 0.5f
                // top bowl
                p.moveTo(inset, inset + stroke * 0.8f)
                p.quadTo(inset, inset, inset + stroke, inset)
                p.lineTo(w - inset - stroke, inset)
                p.quadTo(w - inset, inset, w - inset, inset + stroke)
                p.lineTo(w - inset, mid - stroke * 0.4f)
                p.quadTo(w - inset, mid + stroke * 0.3f, w - inset - stroke, mid + stroke * 0.5f)
                p.lineTo(inset + stroke * 1.5f, mid + stroke * 0.5f)
                p.lineTo(inset + stroke * 1.5f, mid - stroke * 0.5f)
                p.lineTo(w - inset - stroke, mid - stroke * 0.5f)
                p.lineTo(w - inset - stroke, inset + stroke)
                p.lineTo(inset + stroke, inset + stroke)
                p.close()
                // bottom bowl
                p.moveTo(inset + stroke * 1.5f, mid + stroke * 0.6f)
                p.lineTo(w - inset - stroke, mid + stroke * 0.6f)
                p.quadTo(w - inset, mid + stroke * 0.6f, w - inset, mid + stroke * 1.4f)
                p.lineTo(w - inset, h - inset - stroke)
                p.quadTo(w - inset, h - inset, w - inset - stroke, h - inset)
                p.lineTo(inset + stroke, h - inset)
                p.quadTo(inset, h - inset, inset, h - inset - stroke)
                p.lineTo(inset, h - inset - stroke * 1.2f)
                p.lineTo(inset + stroke, h - inset - stroke * 1.2f)
                p.lineTo(inset + stroke, h - inset - stroke)
                p.lineTo(w - inset - stroke, h - inset - stroke)
                p.lineTo(w - inset - stroke, mid + stroke * 1.5f)
                p.lineTo(inset + stroke * 1.5f, mid + stroke * 1.5f)
                p.close()
            }
            '4' -> {
                // Open 4: vertical + horizontal crossbar
                val barW = stroke * 1.1f
                val crossY = h * 0.62f
                // vertical
                p.addRoundRect(RectF(w * 0.62f - barW / 2, inset, w * 0.62f + barW / 2, h - inset), r, r, Path.Direction.CW)
                // left diagonal/vertical
                p.moveTo(inset + stroke * 0.3f, inset)
                p.lineTo(inset + stroke * 0.3f + stroke, inset)
                p.lineTo(w * 0.62f - barW / 2, crossY)
                p.lineTo(w * 0.62f - barW / 2 - stroke * 0.8f, crossY)
                p.close()
                // cross bar
                p.addRoundRect(RectF(inset + stroke * 0.2f, crossY - stroke * 0.55f, w - inset, crossY + stroke * 0.55f), r * 0.6f, r * 0.6f, Path.Direction.CW)
            }
            '5' -> {
                // Top bar + left vertical + bottom bowl
                val mid = h * 0.42f
                // top bar
                p.addRoundRect(RectF(inset, inset, w - inset, inset + stroke), r * 0.7f, r * 0.7f, Path.Direction.CW)
                // left stem
                p.addRoundRect(RectF(inset, inset, inset + stroke, mid + stroke * 0.5f), r * 0.6f, r * 0.6f, Path.Direction.CW)
                // bottom bowl
                p.moveTo(inset, mid)
                p.lineTo(w - inset - stroke, mid)
                p.quadTo(w - inset, mid, w - inset, mid + stroke)
                p.lineTo(w - inset, h - inset - stroke)
                p.quadTo(w - inset, h - inset, w - inset - stroke, h - inset)
                p.lineTo(inset + stroke, h - inset)
                p.quadTo(inset, h - inset, inset, h - inset - stroke)
                p.lineTo(inset, h - inset - stroke * 1.1f)
                p.lineTo(inset + stroke, h - inset - stroke * 1.1f)
                p.lineTo(inset + stroke, h - inset - stroke)
                p.lineTo(w - inset - stroke, h - inset - stroke)
                p.lineTo(w - inset - stroke, mid + stroke)
                p.lineTo(inset + stroke, mid + stroke)
                p.lineTo(inset + stroke, mid)
                p.close()
            }
            '6' -> {
                // Full rounded with inner hole in lower half
                p.addRoundRect(RectF(inset, inset, w - inset, h - inset), r * 1.7f, r * 1.7f, Path.Direction.CW)
                val hole = Path()
                val holeTop = h * 0.42f
                hole.addRoundRect(RectF(inset + stroke, holeTop, w - inset - stroke, h - inset - stroke), r * 1.0f, r * 1.0f, Path.Direction.CW)
                p.op(hole, Path.Op.DIFFERENCE)
                // top open cut for classic 6 look
                val cut = Path()
                cut.addRect(w * 0.45f, inset, w - inset, inset + stroke * 1.3f, Path.Direction.CW)
                p.op(cut, Path.Op.DIFFERENCE)
            }
            '7' -> {
                // Top bar + diagonal
                p.addRoundRect(RectF(inset, inset, w - inset, inset + stroke), r * 0.7f, r * 0.7f, Path.Direction.CW)
                p.moveTo(w - inset - stroke * 0.3f, inset + stroke)
                p.lineTo(w - inset, inset + stroke)
                p.lineTo(inset + stroke * 1.2f, h - inset)
                p.lineTo(inset + stroke * 0.3f, h - inset)
                p.close()
            }
            '8' -> {
                // Two stacked circles / rounded shapes
                val mid = h * 0.5f
                val gap = stroke * 0.15f
                // top
                p.addRoundRect(RectF(inset, inset, w - inset, mid - gap), r * 1.5f, r * 1.5f, Path.Direction.CW)
                val topHole = Path()
                topHole.addRoundRect(RectF(inset + stroke, inset + stroke, w - inset - stroke, mid - gap - stroke * 0.6f), r * 0.9f, r * 0.9f, Path.Direction.CW)
                p.op(topHole, Path.Op.DIFFERENCE)
                // bottom
                p.addRoundRect(RectF(inset, mid + gap, w - inset, h - inset), r * 1.5f, r * 1.5f, Path.Direction.CW)
                val botHole = Path()
                botHole.addRoundRect(RectF(inset + stroke, mid + gap + stroke * 0.6f, w - inset - stroke, h - inset - stroke), r * 0.9f, r * 0.9f, Path.Direction.CW)
                p.op(botHole, Path.Op.DIFFERENCE)
            }
            '9' -> {
                // Mirror of 6
                p.addRoundRect(RectF(inset, inset, w - inset, h - inset), r * 1.7f, r * 1.7f, Path.Direction.CW)
                val hole = Path()
                val holeBot = h * 0.58f
                hole.addRoundRect(RectF(inset + stroke, inset + stroke, w - inset - stroke, holeBot), r * 1.0f, r * 1.0f, Path.Direction.CW)
                p.op(hole, Path.Op.DIFFERENCE)
                val cut = Path()
                cut.addRect(inset, h - inset - stroke * 1.3f, w * 0.55f, h - inset, Path.Direction.CW)
                p.op(cut, Path.Op.DIFFERENCE)
            }
            ':' -> {
                // Two dots
                val dotR = stroke * 0.7f
                val cx = w * 0.5f
                p.addCircle(cx, h * 0.32f, dotR, Path.Direction.CW)
                p.addCircle(cx, h * 0.68f, dotR, Path.Direction.CW)
            }
            else -> {
                // fallback rectangle
                p.addRoundRect(RectF(inset, inset, w - inset, h - inset), r, r, Path.Direction.CW)
            }
        }
        return p
    }
}
