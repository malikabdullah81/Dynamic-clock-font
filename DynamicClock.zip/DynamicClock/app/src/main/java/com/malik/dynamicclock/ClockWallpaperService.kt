package com.malik.dynamicclock

import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import androidx.core.content.edit
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

class ClockWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = ClockEngine()

    inner class ClockEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private var visible = false
        private val prefs by lazy { getSharedPreferences("dynamic_clock", MODE_PRIVATE) }

        // Animation state
        private var animProgress = 1f          // 0 = start (collapsed), 1 = full
        private var animStartTime = 0L
        private var isAnimating = false
        private val animDurationMs = 850L

        // Cached subject mask (for stretch)
        private var subjectMask: Bitmap? = null
        private var backgroundBitmap: Bitmap? = null
        private var lastBgHash = 0

        private val drawRunnable = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) {
                    handler.postDelayed(this, if (isAnimating) 16 else 1000)
                }
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                // Trigger wake animation
                startWakeAnimation()
                handler.post(drawRunnable)
            } else {
                handler.removeCallbacks(drawRunnable)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(drawRunnable)
            super.onSurfaceDestroyed(holder)
        }

        private fun startWakeAnimation() {
            animProgress = 0f
            animStartTime = System.currentTimeMillis()
            isAnimating = true
        }

        private fun updateAnimation() {
            if (!isAnimating) return
            val elapsed = System.currentTimeMillis() - animStartTime
            val t = (elapsed / animDurationMs.toFloat()).coerceIn(0f, 1f)

            // Custom easing with bounce
            val bounce = prefs.getFloat("bounce", 0.6f)
            animProgress = if (bounce < 0.05f) {
                // smooth ease-out
                1f - (1f - t) * (1f - t)
            } else {
                // spring-like overshoot
                val overshoot = 1f + bounce * 0.35f
                val eased = 1f - (1f - t).pow(2.8f)
                if (t < 0.85f) eased * overshoot
                else {
                    val settle = (t - 0.85f) / 0.15f
                    overshoot - (overshoot - 1f) * (1f - (1f - settle).pow(2f))
                }
            }.coerceIn(0f, 1.25f)

            if (t >= 1f) {
                animProgress = 1f
                isAnimating = false
            }
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) {
                    updateAnimation()
                    drawClock(canvas)
                }
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (_: Exception) {}
                }
            }
        }

        private fun drawClock(canvas: Canvas) {
            val w = canvas.width.toFloat()
            val h = canvas.height.toFloat()

            // Background
            val bgUri = prefs.getString("bg_uri", null)
            if (bgUri != null && backgroundBitmap == null) {
                // Loaded asynchronously in MainActivity; here we just clear
            }
            if (backgroundBitmap != null) {
                canvas.drawBitmap(backgroundBitmap!!, null, RectF(0f, 0f, w, h), null)
            } else {
                canvas.drawColor(Color.BLACK)
            }

            // Time
            val now = Calendar.getInstance()
            val hour = if (prefs.getBoolean("is24h", true)) {
                String.format("%02d", now.get(Calendar.HOUR_OF_DAY))
            } else {
                val h12 = now.get(Calendar.HOUR).let { if (it == 0) 12 else it }
                String.format("%02d", h12)
            }
            val minute = String.format("%02d", now.get(Calendar.MINUTE))
            val timeStr = "$hour:$minute"

            // Settings
            val style = prefs.getString("style", "solid") ?: "solid"
            val baseColor = prefs.getInt("color", Color.WHITE)
            val alpha = (prefs.getFloat("transparency", 0.92f) * 255).toInt()
            val color = Color.argb(alpha, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))
            val digitHeightBase = prefs.getFloat("digit_height", 0.28f) * h
            val digitWidth = prefs.getFloat("digit_width", 0.13f) * w
            val yBase = prefs.getFloat("pos_y", 0.22f) * h
            val strokeScale = prefs.getFloat("stroke", 1f)
            val fitAround = prefs.getBoolean("fit_around", true)
            val tuckBehind = prefs.getBoolean("tuck_behind", false)
            val showDate = prefs.getBoolean("show_date", true)
            val dateSize = prefs.getFloat("date_size", 0.035f) * h
            val dateY = prefs.getFloat("date_y", 0.14f) * h
            val glassFrost = prefs.getFloat("glass_frost", 0.55f)
            val glassTint = prefs.getFloat("glass_tint", 0.35f)

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color
                style = if (style == "outline") Paint.Style.STROKE else Paint.Style.FILL
                strokeWidth = digitWidth * 0.18f * strokeScale
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }

            // Glass setup
            val glassPaint = if (style == "glass") {
                Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    this.color = Color.argb((alpha * 0.7f).toInt(), 255, 255, 255)
                    maskFilter = BlurMaskFilter(digitWidth * 0.12f, BlurMaskFilter.Blur.NORMAL)
                }
            } else null

            // Compute per-character stretch heights
            val chars = timeStr.toCharArray()
            val charWidths = FloatArray(chars.size) { i ->
                if (chars[i] == ':') digitWidth * 0.38f else digitWidth
            }
            val totalWidth = charWidths.sum() + digitWidth * 0.08f * (chars.size - 1)
            var x = (w - totalWidth) / 2f

            val stretchHeights = FloatArray(chars.size) { digitHeightBase }

            if (fitAround && subjectMask != null) {
                // Sample the mask under each digit column to find lowest clear Y
                val mask = subjectMask!!
                val scaleX = mask.width / w
                val scaleY = mask.height / h

                for (i in chars.indices) {
                    val cw = charWidths[i]
                    val sampleLeft = ((x + cw * 0.2f) * scaleX).toInt().coerceIn(0, mask.width - 1)
                    val sampleRight = ((x + cw * 0.8f) * scaleX).toInt().coerceIn(0, mask.width - 1)
                    val startY = ((yBase + digitHeightBase * 0.3f) * scaleY).toInt().coerceIn(0, mask.height - 1)

                    var lowestClear = (yBase + digitHeightBase)
                    // Scan downward from mid of digit for first subject pixel
                    for (sy in startY until mask.height step 3) {
                        var hit = false
                        for (sx in sampleLeft..sampleRight step 2) {
                            val pixel = mask.getPixel(sx, sy)
                            if (Color.alpha(pixel) > 80) { // subject present
                                hit = true
                                break
                            }
                        }
                        if (hit) {
                            lowestClear = sy / scaleY
                            break
                        }
                    }
                    val maxH = (lowestClear - yBase - digitHeightBase * 0.04f).coerceAtLeast(digitHeightBase * 0.45f)
                    stretchHeights[i] = min(digitHeightBase * 1.35f, maxH)
                }
            }

            // Apply animation scale (stretch from top, bottoms move down)
            val animScale = animProgress.coerceIn(0f, 1.15f)

            // Date
            if (showDate) {
                val dateFormat = SimpleDateFormat("EEE, MMM d", Locale.getDefault())
                val dateStr = dateFormat.format(now.time)
                val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    this.color = color
                    textSize = dateSize
                    textAlign = Paint.Align.CENTER
                    typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                    alpha = (alpha * 0.85f).toInt()
                }
                val dateAnimY = dateY + (1f - animScale) * dateSize * 0.6f
                canvas.drawText(dateStr, w / 2f, dateAnimY, datePaint)
            }

            // Draw each character
            for (i in chars.indices) {
                val ch = chars[i]
                val cw = charWidths[i]
                val targetH = stretchHeights[i] * animScale
                val drawY = yBase

                val path = DigitShapes.getPath(ch, cw, targetH, cw * 0.22f * strokeScale)

                canvas.save()
                canvas.translate(x, drawY)

                when (style) {
                    "solid" -> {
                        paint.style = Paint.Style.FILL
                        canvas.drawPath(path, paint)
                    }
                    "outline" -> {
                        paint.style = Paint.Style.STROKE
                        paint.strokeWidth = cw * 0.16f * strokeScale
                        canvas.drawPath(path, paint)
                    }
                    "glass" -> {
                        // Soft frosted fill
                        val gPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = Color.argb(
                                (alpha * (0.45f + glassFrost * 0.4f)).toInt(),
                                (Color.red(baseColor) * (1f - glassTint) + 220 * glassTint).toInt().coerceIn(0, 255),
                                (Color.green(baseColor) * (1f - glassTint) + 230 * glassTint).toInt().coerceIn(0, 255),
                                (Color.blue(baseColor) * (1f - glassTint) + 240 * glassTint).toInt().coerceIn(0, 255)
                            )
                        }
                        canvas.drawPath(path, gPaint)

                        // Subtle top highlight (refractive edge)
                        val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = Color.argb((90 * animScale).toInt(), 255, 255, 255)
                            style = Paint.Style.STROKE
                            strokeWidth = cw * 0.06f
                            maskFilter = BlurMaskFilter(cw * 0.04f, BlurMaskFilter.Blur.NORMAL)
                        }
                        canvas.drawPath(path, highlight)

                        // Very soft outer glow, no hard border
                        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                            color = Color.argb(40, 255, 255, 255)
                            maskFilter = BlurMaskFilter(cw * 0.18f, BlurMaskFilter.Blur.OUTER)
                        }
                        canvas.drawPath(path, glow)
                    }
                }

                canvas.restore()
                x += cw + digitWidth * 0.08f
            }

            // Optional: draw subject on top if tuckBehind
            if (tuckBehind && subjectMask != null && backgroundBitmap != null) {
                // Simple approximation: we would need the original cutout bitmap.
                // For now the stretch already avoids covering the subject.
            }
        }

        fun setBackground(bmp: Bitmap?) {
            backgroundBitmap = bmp
        }

        fun setSubjectMask(mask: Bitmap?) {
            subjectMask = mask
        }
    }
}
