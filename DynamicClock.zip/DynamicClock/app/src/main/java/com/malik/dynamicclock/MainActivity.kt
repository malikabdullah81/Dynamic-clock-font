package com.malik.dynamicclock

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("dynamic_clock", MODE_PRIVATE) }
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val PICK_IMAGE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindControls()
        findViewById<Button>(R.id.btnSetWallpaper).setOnClickListener { setWallpaper() }
        findViewById<Button>(R.id.btnPickBg).setOnClickListener { pickBackground() }
        findViewById<Button>(R.id.btnReplay).setOnClickListener { /* animation is triggered on visibility */ }
        findViewById<Button>(R.id.btnRedoCutout).setOnClickListener { redoCutout() }
    }

    private fun bindControls() {
        // Style
        val styleGroup = findViewById<RadioGroup>(R.id.styleGroup)
        when (prefs.getString("style", "solid")) {
            "outline" -> styleGroup.check(R.id.styleOutline)
            "glass" -> styleGroup.check(R.id.styleGlass)
            else -> styleGroup.check(R.id.styleSolid)
        }
        styleGroup.setOnCheckedChangeListener { _, id ->
            val s = when (id) {
                R.id.styleOutline -> "outline"
                R.id.styleGlass -> "glass"
                else -> "solid"
            }
            prefs.edit { putString("style", s) }
        }

        // Transparency
        setupSlider(R.id.sliderTransparency, "transparency", 0.92f, 0.1f, 1f) { v -> "${(v * 100).toInt()}%" }

        // Bounce
        setupSlider(R.id.sliderBounce, "bounce", 0.6f, 0f, 1f) { v -> "${(v * 100).toInt()}" }

        // Digit height / width / pos
        setupSlider(R.id.sliderDigitH, "digit_height", 0.28f, 0.12f, 0.45f) { v -> "${(v * 100).toInt()}%" }
        setupSlider(R.id.sliderDigitW, "digit_width", 0.13f, 0.07f, 0.22f) { v -> "${(v * 100).toInt()}%" }
        setupSlider(R.id.sliderPosY, "pos_y", 0.22f, 0.05f, 0.55f) { v -> "${(v * 100).toInt()}%" }

        // Date
        findViewById<Switch>(R.id.switchDate).apply {
            isChecked = prefs.getBoolean("show_date", true)
            setOnCheckedChangeListener { _, c -> prefs.edit { putBoolean("show_date", c) } }
        }
        setupSlider(R.id.sliderDateSize, "date_size", 0.035f, 0.02f, 0.06f) { v -> "${(v * 1000).toInt()}" }
        setupSlider(R.id.sliderDateY, "date_y", 0.14f, 0.04f, 0.3f) { v -> "${(v * 100).toInt()}%" }

        // Fit around / tuck
        findViewById<Switch>(R.id.switchFit).apply {
            isChecked = prefs.getBoolean("fit_around", true)
            setOnCheckedChangeListener { _, c -> prefs.edit { putBoolean("fit_around", c) } }
        }
        findViewById<Switch>(R.id.switchTuck).apply {
            isChecked = prefs.getBoolean("tuck_behind", false)
            setOnCheckedChangeListener { _, c -> prefs.edit { putBoolean("tuck_behind", c) } }
        }

        // 24h
        findViewById<Switch>(R.id.switch24h).apply {
            isChecked = prefs.getBoolean("is24h", true)
            setOnCheckedChangeListener { _, c -> prefs.edit { putBoolean("is24h", c) } }
        }

        // Glass
        setupSlider(R.id.sliderFrost, "glass_frost", 0.55f, 0.1f, 1f) { v -> "${(v * 100).toInt()}%" }
        setupSlider(R.id.sliderTint, "glass_tint", 0.35f, 0f, 1f) { v -> "${(v * 100).toInt()}%" }

        // Color buttons
        val colors = listOf(
            Color.WHITE, Color.parseColor("#F5F5F5"), Color.parseColor("#E0E0E0"),
            Color.parseColor("#FF8A80"), Color.parseColor("#80D8FF"), Color.parseColor("#CCFF90"),
            Color.parseColor("#FFD180"), Color.parseColor("#B388FF")
        )
        val colorRow = findViewById<LinearLayout>(R.id.colorRow)
        colors.forEach { c ->
            val v = View(this).apply {
                setBackgroundColor(c)
                layoutParams = LinearLayout.LayoutParams(90, 90).also { it.setMargins(8, 8, 8, 8) }
                setOnClickListener { prefs.edit { putInt("color", c) } }
            }
            colorRow.addView(v)
        }
    }

    private fun setupSlider(id: Int, key: String, def: Float, min: Float, max: Float, label: (Float) -> String) {
        val seek = findViewById<SeekBar>(id)
        val tv = findViewById<TextView>(resources.getIdentifier(resources.getResourceEntryName(id) + "Label", "id", packageName))
        val range = max - min
        seek.max = 1000
        val cur = prefs.getFloat(key, def)
        seek.progress = ((cur - min) / range * 1000).toInt().coerceIn(0, 1000)
        tv?.text = label(cur)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = min + (p / 1000f) * range
                prefs.edit { putFloat(key, v) }
                tv?.text = label(v)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun pickBackground() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                scope.launch {
                    processBackground(uri)
                }
            }
        }
    }

    private suspend fun processBackground(uri: Uri) = withContext(Dispatchers.IO) {
        try {
            val stream = contentResolver.openInputStream(uri)
            val bmp = BitmapFactory.decodeStream(stream)
            stream?.close()
            if (bmp == null) return@withContext

            // Save a scaled version
            val scaled = Bitmap.createScaledBitmap(bmp, 1080, (1080f * bmp.height / bmp.width).toInt(), true)
            val file = File(filesDir, "bg.jpg")
            FileOutputStream(file).use { scaled.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            prefs.edit { putString("bg_uri", file.absolutePath) }

            // Run segmentation
            val options = SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .build()
            val segmenter = Segmentation.getClient(options)
            val image = InputImage.fromBitmap(scaled, 0)

            segmenter.process(image)
                .addOnSuccessListener { mask ->
                    // Create binary-ish mask bitmap
                    val maskBmp = Bitmap.createBitmap(mask.width, mask.height, Bitmap.Config.ARGB_8888)
                    val buffer = mask.buffer
                    buffer.rewind()
                    for (y in 0 until mask.height) {
                        for (x in 0 until mask.width) {
                            val conf = buffer.float
                            val alpha = (conf * 255).toInt().coerceIn(0, 255)
                            maskBmp.setPixel(x, y, Color.argb(alpha, 255, 255, 255))
                        }
                    }
                    val maskFile = File(filesDir, "mask.png")
                    FileOutputStream(maskFile).use { maskBmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    prefs.edit { putString("mask_uri", maskFile.absolutePath) }
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Background + cut-out ready", Toast.LENGTH_SHORT).show()
                    }
                }
                .addOnFailureListener {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Cut-out failed: ${it.message}", Toast.LENGTH_LONG).show()
                    }
                }
        } catch (e: Exception) {
            runOnUiThread {
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun redoCutout() {
        val path = prefs.getString("bg_uri", null) ?: return
        val file = File(path)
        if (!file.exists()) return
        scope.launch {
            processBackground(Uri.fromFile(file))
        }
    }

    private fun setWallpaper() {
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        intent.putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, ClockWallpaperService::class.java)
        )
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
