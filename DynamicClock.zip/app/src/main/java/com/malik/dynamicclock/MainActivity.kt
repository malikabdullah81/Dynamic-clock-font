package com.malik.dynamicclock

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

/**
 * Settings screen. The window is transparent in its top half, so while Dynamic Clock is your
 * active wallpaper you see every change live on the clock above the panel.
 */
class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private val reqImage = 11

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(Cfg.FILE, MODE_PRIVATE)

        val d = resources.displayMetrics.density
        val screenH = resources.displayMetrics.heightPixels

        val root = FrameLayout(this)
        val panel = ScrollView(this)
        val shape = GradientDrawable()
        shape.setColor(0xF2101522.toInt())
        val r = 28f * d
        shape.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        panel.background = shape

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val pad = (20 * d).toInt()
        col.setPadding(pad, pad, pad, pad + (8 * d).toInt())
        panel.addView(
            col,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        root.addView(
            panel,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (screenH * 0.56f).toInt(),
                Gravity.BOTTOM
            )
        )
        setContentView(root)

        panel.setOnApplyWindowInsetsListener { v, insets ->
            v.setPadding(0, 0, 0, insets.systemWindowInsetBottom)
            insets
        }

        col.addView(label("Dynamic Clock", 22f, Color.WHITE, true))
        col.addView(
            label(
                "A tall tube clock drawn by the app. Set it as your wallpaper, then change things here " +
                    "and watch the clock above.",
                13f, 0xFF94A3B8.toInt(), false
            )
        )

        col.addView(button("Set as wallpaper") { setWallpaper() })
        col.addView(button("Pick background picture") { pickImage() })

        col.addView(button("Redo subject cut-out") { runCutout() })
        addSwitch(col, "Clock fits around the subject (digits stretch down to its edge)", Cfg.FIT, true)
        addSwitch(col, "Also tuck the clock behind the subject", Cfg.WRAP, false)

        // ----- wake-up animation -----
        col.addView(label("Wake-up animation", 15f, Color.WHITE, true))
        addSwitch(col, "Animate the clock when the screen wakes", Cfg.WAKE_ANIM, true)
        addSlider(col, "Animation speed", Cfg.ANIM_SPEED, 50, 200, 100, " %")
        addSlider(col, "Bounce (0 = smooth, no bounce)", Cfg.ANIM_BOUNCE, 0, 100, 60, " %")
        val animLabel = label("", 13f, 0xFFCBD5E1.toInt(), false)
        val animNames = arrayOf("Stretch down", "Stretch up", "Dots grow")
        fun showAnim() {
            animLabel.text = "Animation: " + animNames[prefs.getInt(Cfg.ANIM_STYLE, 0).coerceIn(0, 2)]
        }
        showAnim()
        col.addView(animLabel)
        val animRow = LinearLayout(this)
        animRow.orientation = LinearLayout.HORIZONTAL
        for (i in 0..2) {
            val ab = button(animNames[i]) {
                prefs.edit().putInt(Cfg.ANIM_STYLE, i).apply()
                showAnim()
                bump(Cfg.REPLAY)
            }
            animRow.addView(ab, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(animRow)
        col.addView(button("Replay animation") {
            prefs.edit().putInt(Cfg.REPLAY, prefs.getInt(Cfg.REPLAY, 0) + 1).apply()
        })

        // ----- look -----
        col.addView(label("Look", 15f, Color.WHITE, true))
        val styleLabel = label("", 13f, 0xFFCBD5E1.toInt(), false)
        val styleNames = arrayOf("Solid", "Outline", "Glass")
        fun showStyle() {
            styleLabel.text = "Style: " + styleNames[prefs.getInt(Cfg.STYLE, 0).coerceIn(0, 2)]
        }
        showStyle()
        col.addView(styleLabel)
        val styleRow = LinearLayout(this)
        styleRow.orientation = LinearLayout.HORIZONTAL
        for (i in 0..2) {
            val b = button(styleNames[i]) {
                prefs.edit().putInt(Cfg.STYLE, i).apply()
                showStyle()
            }
            styleRow.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(styleRow)

        addSlider(col, "Transparency (100 = solid)", Cfg.ALPHA, 10, 100, 100, " %")
        addSlider(col, "Glass colour tint", Cfg.GLASS_TINT, 0, 100, 22, " %")
        addSlider(col, "Glass frost (blur of picture)", Cfg.GLASS_FROST, 0, 100, 30, " %")
        addSlider(col, "Glass refraction (bends the picture inside the glass)", Cfg.GLASS_REFRACT, 0, 100, 40, " %")
        addSlider(col, "Glass edge light (0 = no edge line at all)", Cfg.GLASS_EDGE, 0, 100, 40, " %")
        addSlider(col, "Outline / rim thickness", Cfg.OUTLINE, 1, 12, Cfg.DEF_OUTLINE, " dp")

        // ----- colour -----
        col.addView(label("Colour", 15f, Color.WHITE, true))
        addSwitch(col, "Auto colour (light or dark from picture)", Cfg.COLOR_AUTO, true)
        col.addView(label("Quick colours (turns auto colour off)", 13f, 0xFFCBD5E1.toInt(), false))
        addSwatches(col)
        addSlider(col, "Hue", Cfg.HUE, 0, 360, 0, "")
        addSlider(col, "Saturation", Cfg.SAT, 0, 100, 0, " %")
        addSlider(col, "Brightness", Cfg.VAL, 0, 100, 100, " %")
        col.addView(label("Hue, saturation and brightness are used when auto colour is off.", 12f, 0xFF94A3B8.toInt(), false))

        // ----- shape -----
        col.addView(label("Shape", 15f, Color.WHITE, true))
        addSlider(col, "Digit height", Cfg.SIZE, 80, 260, Cfg.DEF_SIZE, " dp")
        addSlider(col, "Digit width (low = tall and thin)", Cfg.WIDTH, 30, 70, Cfg.DEF_WIDTH, " %")
        addSlider(col, "Vertical position", Cfg.POS, 10, 60, Cfg.DEF_POS, " %")
        addSwitch(col, "24-hour time", Cfg.HOUR24, false)

        // ----- date -----
        col.addView(label("Date", 15f, Color.WHITE, true))
        addSwitch(col, "Show date", Cfg.SHOW_DATE, true)
        addSwitch(col, "Date below the clock", Cfg.DATE_BELOW, false)
        addSwitch(col, "UPPERCASE", Cfg.DATE_UPPER, false)
        val fmtLabel = label("", 13f, 0xFFCBD5E1.toInt(), false)
        fun showFmt() {
            fmtLabel.text = "Date format: " +
                Cfg.DATE_NAMES[prefs.getInt(Cfg.DATE_FORMAT, 0).coerceIn(0, Cfg.DATE_NAMES.size - 1)]
        }
        showFmt()
        col.addView(fmtLabel)
        val fmtRowA = LinearLayout(this)
        fmtRowA.orientation = LinearLayout.HORIZONTAL
        val fmtRowB = LinearLayout(this)
        fmtRowB.orientation = LinearLayout.HORIZONTAL
        for (i in Cfg.DATE_NAMES.indices) {
            val fb = button(Cfg.DATE_NAMES[i]) {
                prefs.edit().putInt(Cfg.DATE_FORMAT, i).apply()
                showFmt()
            }
            val row = if (i < 2) fmtRowA else fmtRowB
            row.addView(fb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(fmtRowA)
        col.addView(fmtRowB)
        addSlider(col, "Date size", Cfg.DATE_SIZE, 50, 200, 100, " %")
        addSlider(col, "Date distance from the clock", Cfg.DATE_GAP, 0, 300, 100, " %")
        addSlider(col, "Date thickness", Cfg.DATE_WEIGHT, 100, 900, 400, "")
        addSlider(col, "Date opacity", Cfg.DATE_ALPHA, 20, 100, 88, " %")

        // ----- thickness -----
        col.addView(label("Thickness (font weight)", 15f, Color.WHITE, true))
        addSwitch(col, "Auto thickness (from picture)", Cfg.WEIGHT_AUTO, true)
        addSlider(col, "Thinnest (calm picture)", Cfg.WEIGHT_MIN, 100, 500, Cfg.DEF_WMIN, "")
        addSlider(col, "Thickest (busy or bright picture)", Cfg.WEIGHT_MAX, 400, 900, Cfg.DEF_WMAX, "")
        addSlider(col, "Fixed thickness (when auto is off)", Cfg.WEIGHT_FIXED, 100, 900, Cfg.DEF_WFIXED, "")

        col.addView(
            label(
                "Samsung's own system clock stays on top on the lock screen. This app only controls the " +
                    "wallpaper's clock.",
                12f, 0xFF94A3B8.toInt(), false
            )
        )
    }

    // ---------- small UI helpers ----------

    private fun label(t: String, sp: Float, color: Int, bold: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sp
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        val top = (10 * resources.displayMetrics.density).toInt()
        v.setPadding(0, top, 0, 0)
        return v
    }

    private fun button(t: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { onClick() }
        return b
    }

    private fun addSwitch(parent: LinearLayout, title: String, key: String, def: Boolean) {
        val s = Switch(this)
        s.text = title
        s.textSize = 15f
        s.setTextColor(Color.WHITE)
        s.isChecked = prefs.getBoolean(key, def)
        s.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
        parent.addView(s)
    }

    private fun addSlider(
        parent: LinearLayout, title: String, key: String,
        lo: Int, hi: Int, def: Int, unit: String
    ) {
        val tv = label("", 13f, 0xFFCBD5E1.toInt(), false)
        val sb = SeekBar(this)
        sb.max = hi - lo
        val start = prefs.getInt(key, def).coerceIn(lo, hi)
        sb.progress = start - lo
        tv.text = "$title: $start$unit"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = lo + progress
                tv.text = "$title: $v$unit"
                if (fromUser) prefs.edit().putInt(key, v).apply()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun addSwatches(parent: LinearLayout) {
        val d = resources.displayMetrics.density
        val colours = intArrayOf(
            0xFFFFFFFF.toInt(), 0xFF111111.toInt(), 0xFFFF8A4C.toInt(),
            0xFFFF5FA2.toInt(), 0xFF5CE1E6.toInt(), 0xFFB6F24A.toInt()
        )
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (c in colours) {
            val b = Button(this)
            b.setBackgroundColor(c)
            b.setOnClickListener {
                val hsv = FloatArray(3)
                Color.colorToHSV(c, hsv)
                prefs.edit()
                    .putInt(Cfg.HUE, hsv[0].toInt())
                    .putInt(Cfg.SAT, (hsv[1] * 100f).toInt())
                    .putInt(Cfg.VAL, (hsv[2] * 100f).toInt())
                    .putBoolean(Cfg.COLOR_AUTO, false)
                    .apply()
                recreate() // reload the sliders with the new values
            }
            val lp = LinearLayout.LayoutParams(0, (40 * d).toInt(), 1f)
            lp.setMargins((3 * d).toInt(), (6 * d).toInt(), (3 * d).toInt(), (6 * d).toInt())
            row.addView(b, lp)
        }
        parent.addView(row)
    }

    // ---------- actions ----------

    private fun setWallpaper() {
        val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
        intent.putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, DynamicClockService::class.java)
        )
        try {
            startActivity(intent)
        } catch (e: Exception) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        startActivityForResult(i, reqImage)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == reqImage) importImage(uri)
    }

    private fun bump(key: String) {
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show() }
    }

    private fun importImage(uri: Uri) {
        Thread {
            try {
                val source = ImageDecoder.createSource(contentResolver, uri)
                val bmp = ImageDecoder.decodeBitmap(source) { dec, info, _ ->
                    val w = info.size.width
                    val h = info.size.height
                    val longSide = if (w > h) w else h
                    if (longSide > 2400) {
                        val s = 2400f / longSide
                        dec.setTargetSize((w * s).toInt(), (h * s).toInt())
                    }
                    dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
                FileOutputStream(File(filesDir, Cfg.BG_FILE)).use {
                    bmp.compress(Bitmap.CompressFormat.JPEG, 92, it)
                }
                File(filesDir, Cfg.SUBJECT_FILE).delete()   // old cut-out belongs to the old picture
                bump(Cfg.BG_VERSION)
                toast("Background updated")
                runCutout()
            } catch (e: Throwable) {
                toast("Couldn't load that picture")
            }
        }.start()
    }

    /** Finds the person / object in the saved background and lets the clock wrap behind it. */
    private fun runCutout() {
        Thread {
            try {
                val f = File(filesDir, Cfg.BG_FILE)
                if (!f.exists()) {
                    toast("Pick a background picture first")
                    return@Thread
                }
                val bmp = BitmapFactory.decodeFile(f.path)
                if (bmp == null) {
                    toast("Couldn't read the background picture")
                    return@Thread
                }
                toast("Finding the subject...")
                SubjectCutout.create(bmp, File(filesDir, Cfg.SUBJECT_FILE)) { ok, msg ->
                    if (ok) {
                        bump(Cfg.BG_VERSION)
                        toast("Subject found: the clock now wraps behind it")
                    } else {
                        toast("No cut-out (" + (msg ?: "unknown") + "). It needs Google Play services and internet the first time. Try again in a minute.")
                    }
                }
            } catch (e: Throwable) {
                toast("Couldn't cut out a subject")
            }
        }.start()
    }
}
