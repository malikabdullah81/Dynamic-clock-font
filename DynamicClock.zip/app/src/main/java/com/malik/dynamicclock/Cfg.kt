package com.malik.dynamicclock

/** Setting names and default values shared by the settings screen and the wallpaper. */
object Cfg {
    const val FILE = "dynamic_clock"

    const val STYLE = "style"               // 0 solid, 1 outline (hollow), 2 glass
    const val SIZE = "size"                 // digit height in dp
    const val DEF_SIZE = 150
    const val WIDTH = "width"               // digit width as % of digit height (tall and narrow = low)
    const val DEF_WIDTH = 48
    const val POS = "pos"                   // vertical position of the clock, % of screen height
    const val DEF_POS = 35

    const val COLOR_AUTO = "color_auto"     // choose light/dark text from the picture behind it
    const val HUE = "hue"                   // custom colour, used when auto colour is off
    const val SAT = "sat"
    const val VAL = "val"
    const val ALPHA = "alpha"               // transparency of the whole clock, 10..100 %
    const val GLASS_TINT = "glass_tint"     // how much colour the glass takes, %
    const val GLASS_FROST = "glass_frost"   // how frosted (blurred) the glass is, %
    const val OUTLINE = "outline"           // outline / rim thickness in dp
    const val DEF_OUTLINE = 3

    const val WEIGHT_AUTO = "weight_auto"   // choose stroke thickness from the picture behind it
    const val WEIGHT_FIXED = "weight_fixed"
    const val DEF_WFIXED = 500
    const val WEIGHT_MIN = "weight_min"
    const val DEF_WMIN = 300
    const val WEIGHT_MAX = "weight_max"
    const val DEF_WMAX = 750

    const val HOUR24 = "hour24"
    const val SHOW_DATE = "show_date"

    const val WAKE_ANIM = "wake_anim"       // dot-to-digit animation when the screen wakes
    const val ANIM_SPEED = "anim_speed"     // 50..200 %, 100 = normal
    const val ANIM_STYLE = "anim_style"     // 0 stretch down, 1 stretch up, 2 dots grow
    const val ANIM_BOUNCE = "anim_bounce"   // 0 = smooth, 100 = very bouncy
    const val REPLAY = "replay"             // bumped by the "Replay animation" button

    const val BG_VERSION = "bg_version"
    const val BG_FILE = "bg.jpg"
    const val SUBJECT_FILE = "subject.png"  // cut-out of the person/object in the picture
    const val WRAP = "wrap"                 // also draw the cut-out in front of the clock (tuck behind)
    const val FIT = "fit"                   // digits stretch / shrink to fit around the subject
}
