package com.malik.dynamicclock

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Live wallpaper with a tall, rounded "tube" clock drawn by the app itself (no font needed).
 * Three looks: Solid, Outline (hollow tubes) and Glass (frosted, picks up the picture behind it).
 * Thickness and colour adapt to the picture behind the clock and glide smoothly.
 */
class DynamicClockService : WallpaperService() {

    override fun onCreateEngine(): Engine = ClockEngine()

    private inner class ClockEngine : Engine(), SharedPreferences.OnSharedPreferenceChangeListener {

        private val handler = Handler(Looper.getMainLooper())
        private val prefs: SharedPreferences = getSharedPreferences(Cfg.FILE, Context.MODE_PRIVATE)

        private var visible = false
        private var sw = 0
        private var sh = 0

        private var bg: Bitmap? = null
        private var blurSmall: Bitmap? = null

        private var dirty = true
        private var rebuildBg = true
        private var lastMinute = -1L

        // settings read in relayout()
        private var style = 0
        private var alphaPct = 100
        private var glassTint = 22
        private var glassFrost = 70
        private var outlineT = 3f
        private var showDate = true

        // geometry
        private var timeText = "0000:00"
        private var dateText = ""
        private var digitH = 0f
        private var cw = 0f
        private var gap = 0f
        private var colonCell = 0f
        private var originX = 0f
        private var topY = 0f
        private var dateSize = 0f
        private var dateBaseline = 0f
        private val region = Rect()

        // off-screen layers the clock is composed in
        private var layerL = 0
        private var layerT = 0
        private var layerW = 1
        private var layerH = 1
        private var layerBmp: Bitmap? = null
        private var layerCv: Canvas? = null
        private var glassBmp: Bitmap? = null
        private var glassCv: Canvas? = null
        private var ringBmp: Bitmap? = null
        private var ringCv: Canvas? = null

        // paints
        private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        }
        private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        private val layerPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        private val srcInPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        }
        private val frostPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        }
        private val tintPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP) }
        private val hiPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP) }
        private val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, 500, false)
        }
        private val srcRect = Rect()
        private val smallRect = Rect()
        private val dstRect = RectF()

        // r, g, b, weight, shadow strength. "tgt" is what the picture asks for, "cur" glides towards it.
        private val tgt = FloatArray(5)
        private val cur = FloatArray(5)
        private var haveCur = false
        private var animating = false

        private val tickRunnable = Runnable { tick() }

        private fun density(): Float = resources.displayMetrics.density

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            prefs.registerOnSharedPreferenceChangeListener(this)
        }

        override fun onDestroy() {
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            handler.removeCallbacksAndMessages(null)
            super.onDestroy()
        }

        override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
            if (key == Cfg.BG_VERSION) rebuildBg = true
            dirty = true
            if (visible) {
                handler.removeCallbacks(tickRunnable)
                handler.post(tickRunnable)
            }
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                dirty = true
                tick()
            } else {
                handler.removeCallbacks(tickRunnable)
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            sw = width
            sh = height
            rebuildBg = true
            dirty = true
            if (visible) tick()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(tickRunnable)
            super.onSurfaceDestroyed(holder)
        }

        private fun tick() {
            handler.removeCallbacks(tickRunnable)
            if (!visible || sw <= 0 || sh <= 0) return

            val minute = System.currentTimeMillis() / 60000L
            if (rebuildBg || bg == null) {
                buildBackground()
                rebuildBg = false
                dirty = true
            }
            if (dirty || minute != lastMinute) {
                lastMinute = minute
                dirty = false
                relayout()
                analyze()
            }
            stepAnimation()
            drawFrame()

            val delay = if (animating) 16L else 60000L - (System.currentTimeMillis() % 60000L) + 40L
            handler.postDelayed(tickRunnable, delay)
        }

        // ---------- background picture ----------

        private fun buildBackground() {
            val w = sw
            val h = sh
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)

            var src: Bitmap? = null
            val f = File(filesDir, Cfg.BG_FILE)
            if (f.exists()) {
                try {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(f.path, bounds)
                    var s = 1
                    while (bounds.outWidth / (s * 2) >= w && bounds.outHeight / (s * 2) >= h) s *= 2
                    val opts = BitmapFactory.Options().apply { inSampleSize = s }
                    src = BitmapFactory.decodeFile(f.path, opts)
                } catch (e: Throwable) {
                    src = null
                }
            }

            if (src != null) {
                // "centre crop": fill the screen, keep the picture's proportions
                val scale = max(w / src.width.toFloat(), h / src.height.toFloat())
                val dx = (w - src.width * scale) / 2f
                val dy = (h - src.height * scale) / 2f
                val m = Matrix()
                m.postScale(scale, scale)
                m.postTranslate(dx, dy)
                c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
                src.recycle()
            } else {
                // default background until a picture is chosen
                val p = Paint()
                p.shader = LinearGradient(
                    0f, 0f, w.toFloat(), h.toFloat(),
                    intArrayOf(0xFF0B1B4D.toInt(), 0xFF3A1C71.toInt(), 0xFF0F6E8C.toInt()),
                    floatArrayOf(0f, 0.55f, 1f),
                    Shader.TileMode.CLAMP
                )
                c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            }
            bg?.recycle()
            bg = out

            // a very soft copy of the picture, used for the frosted-glass look
            val s1 = Bitmap.createScaledBitmap(out, max(1, w / 4), max(1, h / 4), true)
            val s2 = Bitmap.createScaledBitmap(s1, max(1, w / 20), max(1, h / 20), true)
            if (s1 !== s2) s1.recycle()
            blurSmall?.recycle()
            blurSmall = s2
        }

        // ---------- layout ----------

        private fun relayout() {
            val d = density()
            val sizeDp = prefs.getInt(Cfg.SIZE, Cfg.DEF_SIZE)
            val widthPct = prefs.getInt(Cfg.WIDTH, Cfg.DEF_WIDTH)
            val posPct = prefs.getInt(Cfg.POS, Cfg.DEF_POS)
            val h24 = prefs.getBoolean(Cfg.HOUR24, false)
            showDate = prefs.getBoolean(Cfg.SHOW_DATE, true)
            style = prefs.getInt(Cfg.STYLE, 0)
            alphaPct = prefs.getInt(Cfg.ALPHA, 100)
            glassTint = prefs.getInt(Cfg.GLASS_TINT, 22)
            glassFrost = prefs.getInt(Cfg.GLASS_FROST, 70)
            outlineT = prefs.getInt(Cfg.OUTLINE, Cfg.DEF_OUTLINE) * d

            val now = Date()
            timeText = SimpleDateFormat(if (h24) "HH:mm" else "hh:mm", Locale.US).format(now)
            dateText = SimpleDateFormat("EEE, d MMMM", Locale.getDefault()).format(now)

            val wf = widthPct / 100f
            val unit = 4f * wf + 4f * 0.06f + 0.18f     // total width in units of digit height
            var hh = sizeDp * d
            if (hh * unit > sw * 0.94f) hh = sw * 0.94f / unit
            digitH = hh
            cw = hh * wf
            gap = hh * 0.06f
            colonCell = hh * 0.18f
            val totalW = hh * unit
            originX = (sw - totalW) / 2f
            topY = sh * posPct / 100f - hh / 2f

            dateSize = max(hh * 0.075f, 13f * d)
            dateBaseline = topY - dateSize * 0.8f

            // the picture area behind the clock (and date): this is what gets measured
            val dateTop = if (showDate) dateBaseline - dateSize else topY
            val rl = originX.toInt().coerceIn(0, sw - 1)
            val rr = (originX + totalW).toInt().coerceIn(rl + 1, sw)
            val rt = dateTop.toInt().coerceIn(0, sh - 1)
            val rb = (topY + hh).toInt().coerceIn(rt + 1, sh)
            region.set(rl, rt, rr, rb)

            // off-screen layer a little bigger than the digits (room for shadow and rim)
            val pad = 24f * d
            layerL = (originX - pad).toInt().coerceIn(0, sw - 1)
            layerT = (topY - pad).toInt().coerceIn(0, sh - 1)
            val lr = (originX + totalW + pad).toInt().coerceIn(layerL + 1, sw)
            val lb = (topY + hh + pad).toInt().coerceIn(layerT + 1, sh)
            layerW = lr - layerL
            layerH = lb - layerT
            ensureLayers()

            shadowPaint.maskFilter = BlurMaskFilter(7f * d, BlurMaskFilter.Blur.NORMAL)
            hiPaint.shader = LinearGradient(
                0f, 0f, 0f, layerH * 0.7f,
                Color.argb(120, 255, 255, 255), Color.argb(0, 255, 255, 255),
                Shader.TileMode.CLAMP
            )
        }

        private fun ensureLayers() {
            val old = layerBmp
            if (old != null && old.width == layerW && old.height == layerH) return
            layerBmp?.recycle()
            glassBmp?.recycle()
            ringBmp?.recycle()
            val a = Bitmap.createBitmap(layerW, layerH, Bitmap.Config.ARGB_8888)
            val b = Bitmap.createBitmap(layerW, layerH, Bitmap.Config.ARGB_8888)
            val c = Bitmap.createBitmap(layerW, layerH, Bitmap.Config.ARGB_8888)
            layerBmp = a
            layerCv = Canvas(a)
            glassBmp = b
            glassCv = Canvas(b)
            ringBmp = c
            ringCv = Canvas(c)
        }

        // ---------- measuring the picture behind the clock ----------

        private fun analyze() {
            val b = bg ?: return
            val stepX = max(1, region.width() / 28)
            val stepY = max(1, region.height() / 28)

            var n = 0
            var sr = 0.0
            var sg = 0.0
            var sb = 0.0
            var sl = 0.0
            var sl2 = 0.0

            var y = region.top
            while (y < region.bottom) {
                var x = region.left
                while (x < region.right) {
                    val px = b.getPixel(x.coerceIn(0, b.width - 1), y.coerceIn(0, b.height - 1))
                    val r = Color.red(px) / 255.0
                    val g = Color.green(px) / 255.0
                    val bl = Color.blue(px) / 255.0
                    val l = 0.2126 * r + 0.7152 * g + 0.0722 * bl
                    sr += r
                    sg += g
                    sb += bl
                    sl += l
                    sl2 += l * l
                    n++
                    x += stepX
                }
                y += stepY
            }
            if (n == 0) return

            val mean = sl / n
            val std = sqrt(max(0.0, sl2 / n - mean * mean))
            val hsv = FloatArray(3)
            Color.RGBToHSV(
                (sr / n * 255).roundToInt().coerceIn(0, 255),
                (sg / n * 255).roundToInt().coerceIn(0, 255),
                (sb / n * 255).roundToInt().coerceIn(0, 255),
                hsv
            )

            val dark = mean < 0.5
            val colour = if (!prefs.getBoolean(Cfg.COLOR_AUTO, true)) {
                Color.HSVToColor(
                    floatArrayOf(
                        prefs.getInt(Cfg.HUE, 0).toFloat(),
                        prefs.getInt(Cfg.SAT, 0) / 100f,
                        prefs.getInt(Cfg.VAL, 100) / 100f
                    )
                )
            } else if (dark) {
                Color.HSVToColor(floatArrayOf(hsv[0], min(hsv[1] * 0.3f, 0.35f), 0.97f))
            } else {
                Color.HSVToColor(floatArrayOf(hsv[0], min(hsv[1] * 0.7f, 0.75f), 0.13f))
            }

            // difficulty: busy picture or mid-grey picture (poor contrast) -> thicker strokes
            val busy = (std / 0.22).coerceIn(0.0, 1.0)
            val mid = (1.0 - abs(mean - 0.5) * 2.0).coerceIn(0.0, 1.0)
            val difficulty = max(busy, mid * 0.8)

            val wMin = prefs.getInt(Cfg.WEIGHT_MIN, Cfg.DEF_WMIN)
            val wMax = max(wMin, prefs.getInt(Cfg.WEIGHT_MAX, Cfg.DEF_WMAX))
            val weight = if (prefs.getBoolean(Cfg.WEIGHT_AUTO, true)) {
                wMin + (difficulty * (wMax - wMin)).toFloat()
            } else {
                prefs.getInt(Cfg.WEIGHT_FIXED, Cfg.DEF_WFIXED).toFloat()
            }

            tgt[0] = Color.red(colour).toFloat()
            tgt[1] = Color.green(colour).toFloat()
            tgt[2] = Color.blue(colour).toFloat()
            tgt[3] = weight
            tgt[4] = (difficulty * 0.5).toFloat()

            if (!haveCur) {
                for (i in 0..4) cur[i] = tgt[i]
                haveCur = true
            }
        }

        private fun stepAnimation() {
            var moving = false
            for (i in 0..4) {
                val diff = tgt[i] - cur[i]
                val eps = if (i < 3) 0.6f else if (i == 3) 1.0f else 0.01f
                if (abs(diff) > eps) {
                    cur[i] += diff * 0.14f
                    moving = true
                } else {
                    cur[i] = tgt[i]
                }
            }
            animating = moving
        }

        // ---------- the digits ----------

        /** Centre-lines of the four digits and the colon, as one path, relative to the layer. */
        private fun glyphPath(stroke: Float): Path {
            val p = Path()
            val w = cw - stroke
            val h = digitH - stroke
            val y = topY - layerT + stroke / 2f
            val x0 = originX - layerL + stroke / 2f

            addDigit(p, timeText[0], x0, y, w, h)
            addDigit(p, timeText[1], x0 + cw + gap, y, w, h)

            val d2end = originX - layerL + 2f * cw + gap
            val colonX = d2end + gap + colonCell / 2f
            p.moveTo(colonX, y + 0.30f * h)
            p.lineTo(colonX, y + 0.35f * h)
            p.moveTo(colonX, y + 0.62f * h)
            p.lineTo(colonX, y + 0.67f * h)

            val x3 = d2end + 2f * gap + colonCell + stroke / 2f
            addDigit(p, timeText[3], x3, y, w, h)
            addDigit(p, timeText[4], x3 + cw + gap, y, w, h)
            return p
        }

        private fun addDigit(p: Path, ch: Char, x: Float, y: Float, w: Float, h: Float) {
            when (ch) {
                '0' -> p.addRoundRect(RectF(x, y, x + w, y + h), w / 2f, w / 2f, Path.Direction.CW)
                '1' -> {
                    p.moveTo(x, y + 0.22f * h)
                    p.lineTo(x + 0.62f * w, y)
                    p.lineTo(x + 0.62f * w, y + h)
                }
                '2' -> {
                    p.moveTo(x, y + w / 2f)
                    p.arcTo(RectF(x, y, x + w, y + w), 180f, 180f, false)
                    val top = y + w / 2f
                    p.cubicTo(x + w, top + (h - w / 2f) * 0.45f, x, top + (h - w / 2f) * 0.55f, x, y + h)
                    p.lineTo(x + w, y + h)
                }
                '3' -> {
                    p.arcTo(RectF(x, y, x + w, y + 0.5f * h), 200f, 250f, true)
                    p.arcTo(RectF(x, y + 0.5f * h, x + w, y + h), 270f, 250f, false)
                }
                '4' -> {
                    p.moveTo(x + 0.72f * w, y + h)
                    p.lineTo(x + 0.72f * w, y)
                    p.lineTo(x, y + 0.68f * h)
                    p.lineTo(x + w, y + 0.68f * h)
                }
                '5' -> {
                    p.moveTo(x + w, y)
                    p.lineTo(x + 0.1f * w, y)
                    p.lineTo(x + 0.04f * w, y + 0.45f * h)
                    p.arcTo(RectF(x, y + 0.38f * h, x + w, y + h), 235f, 250f, false)
                }
                '6' -> {
                    p.moveTo(x + 0.92f * w, y + 0.04f * h)
                    p.cubicTo(x + 0.30f * w, y, x, y + 0.30f * h, x, y + 0.69f * h)
                    p.arcTo(RectF(x, y + 0.38f * h, x + w, y + h), 180f, -359.5f, false)
                }
                '7' -> {
                    p.moveTo(x, y)
                    p.lineTo(x + w, y)
                    p.cubicTo(x + 0.75f * w, y + 0.35f * h, x + 0.45f * w, y + 0.7f * h, x + 0.35f * w, y + h)
                }
                '8' -> {
                    p.addOval(RectF(x + 0.04f * w, y, x + 0.96f * w, y + 0.52f * h), Path.Direction.CW)
                    p.addOval(RectF(x, y + 0.46f * h, x + w, y + h), Path.Direction.CW)
                }
                '9' -> {
                    p.arcTo(RectF(x, y, x + w, y + 0.62f * h), 0f, -359.5f, true)
                    p.cubicTo(x + w, y + 0.7f * h, x + 0.7f * w, y + h, x + 0.08f * w, y + 0.95f * h)
                }
                else -> {
                }
            }
        }

        // ---------- drawing ----------

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) draw(canvas)
            } catch (e: Throwable) {
            } finally {
                if (canvas != null) {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: Throwable) {
                    }
                }
            }
        }

        private fun draw(c: Canvas) {
            val b = bg
            if (b != null) c.drawBitmap(b, 0f, 0f, null) else c.drawColor(Color.BLACK)
            if (!haveCur) return

            val lb = layerBmp
            val lc = layerCv
            val gb = glassBmp
            val gc = glassCv
            val rb = ringBmp
            val rc = ringCv
            if (lb == null || lc == null || gb == null || gc == null || rb == null || rc == null) return

            val d = density()
            val col = Color.rgb(
                cur[0].roundToInt().coerceIn(0, 255),
                cur[1].roundToInt().coerceIn(0, 255),
                cur[2].roundToInt().coerceIn(0, 255)
            )
            val alphaF = alphaPct / 100f
            layerPaint.alpha = (alphaF * 255f).roundToInt().coerceIn(0, 255)

            // stroke thickness from the weight: 100 -> thin tube, 900 -> very fat tube
            var stroke = digitH * (0.04f + ((cur[3] - 100f) / 800f).coerceIn(0f, 1f) * 0.16f)
            if (style != 0) stroke = max(stroke, outlineT * 2f + digitH * 0.06f)
            stroke = min(stroke, cw * 0.42f)
            val path = glyphPath(stroke)

            // soft shadow under solid and glass digits
            if (style != 1) {
                val sa = (cur[4] * 255f * alphaF).roundToInt().coerceIn(0, 255)
                if (sa > 0) {
                    shadowPaint.strokeWidth = stroke
                    shadowPaint.color = Color.argb(sa, 0, 0, 0)
                    c.save()
                    c.translate(layerL.toFloat(), layerT.toFloat() + 3f * d)
                    c.drawPath(path, shadowPaint)
                    c.restore()
                }
            }

            if (style == 2) {
                // glass: the shape is cut out of the picture, frosted, tinted, with a lit top and a bright rim
                gc.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
                strokePaint.strokeWidth = stroke
                strokePaint.color = Color.WHITE
                gc.drawPath(path, strokePaint)

                srcRect.set(layerL, layerT, layerL + layerW, layerT + layerH)
                dstRect.set(0f, 0f, layerW.toFloat(), layerH.toFloat())
                if (b != null) gc.drawBitmap(b, srcRect, dstRect, srcInPaint)

                val bs = blurSmall
                if (bs != null) {
                    val sx = bs.width / sw.toFloat()
                    val sy = bs.height / sh.toFloat()
                    smallRect.set(
                        (layerL * sx).toInt().coerceIn(0, bs.width - 1),
                        (layerT * sy).toInt().coerceIn(0, bs.height - 1),
                        ((layerL + layerW) * sx).toInt().coerceIn(1, bs.width),
                        ((layerT + layerH) * sy).toInt().coerceIn(1, bs.height)
                    )
                    if (smallRect.width() > 0 && smallRect.height() > 0) {
                        frostPaint.alpha = (glassFrost * 2.55f).roundToInt().coerceIn(0, 255)
                        gc.drawBitmap(bs, smallRect, dstRect, frostPaint)
                    }
                }

                tintPaint.color = Color.argb(
                    (glassTint * 2.55f).roundToInt().coerceIn(0, 255),
                    Color.red(col), Color.green(col), Color.blue(col)
                )
                gc.drawRect(dstRect, tintPaint)
                gc.drawRect(dstRect, hiPaint)

                rc.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
                rimPaint.strokeWidth = stroke
                rimPaint.color = Color.argb(
                    215,
                    (Color.red(col) + 510) / 3, (Color.green(col) + 510) / 3, (Color.blue(col) + 510) / 3
                )
                rc.drawPath(path, rimPaint)
                val rimIn = stroke - 2f * max(1.5f * d, outlineT * 0.5f)
                if (rimIn > 0.5f) {
                    clearPaint.strokeWidth = rimIn
                    rc.drawPath(path, clearPaint)
                }

                c.drawBitmap(gb, layerL.toFloat(), layerT.toFloat(), layerPaint)
                c.drawBitmap(rb, layerL.toFloat(), layerT.toFloat(), layerPaint)
            } else {
                lc.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
                strokePaint.strokeWidth = stroke
                strokePaint.color = col
                lc.drawPath(path, strokePaint)
                if (style == 1) {
                    // outline: cut the inside of the tubes away so only an outline remains
                    val inner = stroke - 2f * outlineT
                    if (inner > 0.5f) {
                        clearPaint.strokeWidth = inner
                        lc.drawPath(path, clearPaint)
                    }
                }
                c.drawBitmap(lb, layerL.toFloat(), layerT.toFloat(), layerPaint)
            }

            if (showDate) {
                datePaint.color = Color.argb(
                    (225f * alphaF).roundToInt().coerceIn(0, 255),
                    Color.red(col), Color.green(col), Color.blue(col)
                )
                datePaint.textSize = dateSize
                c.drawText(dateText, sw / 2f, dateBaseline, datePaint)
            }
        }
    }
}
