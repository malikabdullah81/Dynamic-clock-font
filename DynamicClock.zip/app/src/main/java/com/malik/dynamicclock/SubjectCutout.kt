package com.malik.dynamicclock

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import java.io.File
import java.io.FileOutputStream

/** Cuts the person / object out of a picture with Google's on-device ML Kit and saves it as a PNG. */
object SubjectCutout {

    fun create(source: Bitmap, out: File, done: (Boolean, String?) -> Unit) {
        val options = SubjectSegmenterOptions.Builder()
            .enableForegroundBitmap()
            .build()
        val segmenter = SubjectSegmentation.getClient(options)
        segmenter.process(InputImage.fromBitmap(source, 0))
            .addOnSuccessListener { result ->
                val fg = result.foregroundBitmap
                if (fg == null) {
                    done(false, "no subject found")
                } else {
                    Thread {
                        try {
                            FileOutputStream(out).use { fg.compress(Bitmap.CompressFormat.PNG, 100, it) }
                            done(true, null)
                        } catch (e: Throwable) {
                            done(false, e.message)
                        }
                    }.start()
                }
            }
            .addOnFailureListener { e ->
                done(false, e.message)
            }
    }
}
